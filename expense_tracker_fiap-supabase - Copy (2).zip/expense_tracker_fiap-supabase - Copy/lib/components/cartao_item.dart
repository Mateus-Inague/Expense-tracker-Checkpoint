import 'package:flutter/material.dart';

import '../models/banco.dart';
import '../models/cartao.dart';

class CartaoItem extends StatelessWidget {
  final Cartao cartao;
  const CartaoItem({super.key, required this.cartao});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: AssetImage('images/${bancosMap[cartao.bancoId]?.logo}'),
      ),
      title: Text(cartao.nomeCartao),
      subtitle: Text(bancosMap[cartao.bancoId]?.nome ?? ''),
    );
  }
}

