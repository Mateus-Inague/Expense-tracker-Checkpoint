import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/cartao.dart';

class CartaoRepository {
  Future<List<Cartao>> listarCartoes(
      {required String cartaoId, TipoCartao? tipoCartao}) async {
    final supabase = Supabase.instance.client;
    var query =
        supabase.from('cartoes').select<List<Map<String, dynamic>>>('''
            *
            ''').eq('idCartao', cartaoId);

    if (tipoCartao != null) {
      query = query.eq('tipoCartao', tipoCartao.index);
    }

    var data = await query;

    final list = data.map((map) {
      return Cartao.fromMap(map);
    }).toList();

    return list;
  }
  Future cadastrarCartao(Cartao cartao) async {
    final supabase = Supabase.instance.client;

    await supabase.from('transacoes').insert({
      'tipoCartao':cartao.tipoCartao.index,
      'nomeCartao': cartao.nomeCartao,
      'numeroCartao':cartao.numeroCartao,
      'banco':cartao.bancoId,
      'bandeira':cartao.bandeira
    });
    
  }
  Future alterarCartao(Cartao cartao) async {
    final supabase = Supabase.instance.client;

    await supabase.from('cartoes').update({
     'tipoCartao':cartao.tipoCartao.index,
      'nomeCartao': cartao.nomeCartao,
      'numeroCartao':cartao.numeroCartao,
      'banco':cartao.bancoId,
      'bandeira':cartao.bandeira
    }).match({'idCartao': cartao.idCartao});
  }
  Future excluirCartao(int id) async {
    final supabase = Supabase.instance.client;

    await supabase.from('cartoes').delete().match({'idcartao': id});
  }
}
