class Cartao{
  int idCartao;
  TipoCartao tipoCartao;
  String nomeCartao;
  String numeroCartao;
  String bancoId;
  Bandeira bandeira;
Cartao({
  required this.idCartao,
  required this.tipoCartao,
  required this.nomeCartao,
  required this.numeroCartao,
  required this.bancoId,
  required this.bandeira
});
factory Cartao.fromMap(Map<String, dynamic> map){
  return Cartao(
    idCartao: map['idCartao'],
    tipoCartao: TipoCartao.values[map['tipoCartao']],
    nomeCartao: map['nomeCartao'],
    numeroCartao: map['numeroCartao'],
    bancoId: map['banco'],
    bandeira: Bandeira.values[map['bandeira']]
  );
}

}

enum TipoCartao{credito,debito}
enum Bandeira{mastercard,visa}