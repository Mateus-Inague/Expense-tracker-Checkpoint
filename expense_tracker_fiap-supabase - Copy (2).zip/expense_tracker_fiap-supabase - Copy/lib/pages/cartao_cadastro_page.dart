import 'package:expense_tracker/models/cartao.dart';
import 'package:expense_tracker/repository/cartao_repository.dart';
import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../components/banco_select.dart';
import '../models/banco.dart';
import 'bancos_select_page.dart';

class CartaoCadastroPage extends StatefulWidget {
  final Cartao? cartaoParaEdicao;

  const CartaoCadastroPage({super.key, this.cartaoParaEdicao});

  @override
  State<CartaoCadastroPage> createState() => _CartaoCadastroPageState();
}

class _CartaoCadastroPageState extends State<CartaoCadastroPage> {
  User? user;
  final cartoesRepo = CartaoRepository();
  final nomeController = TextEditingController();
  final numeroController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  Banco? bancoSelecionado;
  TipoCartao tipoCartaoSelecionado = TipoCartao.credito;
  Bandeira tipoBandeiraSelecionada = Bandeira.visa;

  @override
  void initState() {
    user = Supabase.instance.client.auth.currentUser;

    final cartao = widget.cartaoParaEdicao;

    if (cartao != null) {
      tipoCartaoSelecionado = cartao.tipoCartao;
      tipoBandeiraSelecionada = cartao.bandeira;
      numeroController.text = cartao.numeroCartao;
      nomeController.text = cartao.nomeCartao;
   
    }
    super.initState();
  }
    @override
    Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Cadastro de Cartão'),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildNome(),
                  const SizedBox(height: 30),
                  _buildNumero(),
                  const SizedBox(height: 30),
                  _buildBancoSelect(),
                  const SizedBox(height: 30),
                  _buildTipoSelect(),
                  const SizedBox(height: 30),
                  _buildBandeiraSelect(),
                  const SizedBox(height: 30),
                  _buildButton(),
                ],
              ),
            ),
          ),
        ),
      );
    }

    BancoSelect _buildBancoSelect() {
      return BancoSelect(
        banco: bancoSelecionado,
        onTap: () async {
          final result = await Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => const BancosSelectPage(),
            ),
          ) as Banco?;

          if (result != null) {
            setState(() {
              bancoSelecionado = result;
            });
          }
        },
      );
    }

    TextFormField _buildNome() {
      return TextFormField(
        controller: nomeController,
        decoration: const InputDecoration(
          hintText: 'Informe o nome',
          labelText: 'Nome',
          prefixIcon: Icon(Ionicons.text_outline),
          border: OutlineInputBorder(),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Informe O nome completo';
          }
          if (value.length < 5 || value.length > 30) {
            return 'O nome deve entre 5 e 30 caracteres';
          }
          return null;
        },
      );
    }

    TextFormField _buildNumero() {
      return TextFormField(
        controller: numeroController,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(
          labelText: 'Número do Cartão',
          prefixIcon: Icon(Ionicons.text_outline),
          border: OutlineInputBorder(),
        ),
        validator: (value) {
          if (value!.isEmpty) {
            return 'Campo obrigatório';
          }
          if (!isNumeric(value)) {
            return 'Digite apenas números';
          }
          if (value.length != 16) {
            return 'O número do cartão deve ter 16 números';
          }
          return null;
        },
      );
    }

    DropdownMenu<TipoCartao> _buildTipoSelect() {
      return DropdownMenu<TipoCartao>(
        width: MediaQuery.of(context).size.width - 16,
        initialSelection: tipoCartaoSelecionado,
        label: const Text('Tipo de Cartão'),
        dropdownMenuEntries: const [
          DropdownMenuEntry(
            value: TipoCartao.credito,
            label: "Crédito",
          ),
          DropdownMenuEntry(
            value: TipoCartao.debito,
            label: "Débito",
          ),
         
        ],
        onSelected: (value) {
          tipoCartaoSelecionado = value!;
        },
      );
    }

    DropdownMenu<Bandeira> _buildBandeiraSelect() {
      return DropdownMenu<Bandeira>(
        width: MediaQuery.of(context).size.width - 16,
        initialSelection: tipoBandeiraSelecionada,
        label: const Text('Bandeira do cartão'),
        dropdownMenuEntries: const [
          DropdownMenuEntry(
            value: Bandeira.mastercard,
            label: "Mastercard",
          ),
          DropdownMenuEntry(
            value: Bandeira.visa,
            label: "Visa",
          ),
        ],
        onSelected: (value) {
          tipoBandeiraSelecionada = value!;
        },
      );
    }
    SizedBox _buildButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () async {
          final isValid = _formKey.currentState!.validate();
          if (isValid) {
            // Data
            
            // Descricao
            final nome = nomeController.text;
            // Valor
            // Detalhes
            final numero = numeroController.text;
            final tipoCartao = tipoCartaoSelecionado;
            final bandeira = tipoBandeiraSelecionada;
            final bancoId = bancoSelecionado?.id ?? '';
            


            final cartao = Cartao(
              idCartao: 0,
              bancoId: bancoId,
              nomeCartao: nome,
              tipoCartao: tipoCartao,
              numeroCartao: numero,
              bandeira: bandeira
            );

            if (widget.cartaoParaEdicao == null) {
              await _cadastrarCartao(cartao);
            } else {
              cartao.idCartao = widget.cartaoParaEdicao!.idCartao;
              await _alterarCartao(cartao);
            }
          }
        },
        child: const Text('Cadastrar'),
      ),
    );
  }

    bool isNumeric(String? value) {
      if (value == null) {
        return false;
      }
      return double.tryParse(value) != null;
    }
  
   Future<void> _cadastrarCartao(Cartao cartao) async {
    final scaffold = ScaffoldMessenger.of(context);
    await cartoesRepo.cadastrarCartao(cartao).then((_) {
      scaffold.showSnackBar(SnackBar(
        content: Text(
          'Cartão de ${cartao.tipoCartao == TipoCartao.credito ? 'Credito' : 'Debito'}',
        ),
      ));
      Navigator.of(context).pop(true);
    }).catchError((error) {
      scaffold.showSnackBar(SnackBar(
        content: Text(
          'Erro ao cadastrar ${cartao.tipoCartao == TipoCartao.credito ? 'Credito' : 'Debito'}',
        ),
      ));
      Navigator.of(context).pop(false);
    });
  }
  Future<void> _alterarCartao(Cartao cartao) async {
    final scaffold = ScaffoldMessenger.of(context);
    await cartoesRepo.alterarCartao(cartao).then((_) {
      scaffold.showSnackBar(SnackBar(
        content: Text(
          'Cartao alterado com sucesso',
        ),
      ));
      Navigator.of(context).pop(true);
    }).catchError((error) {
      scaffold.showSnackBar(SnackBar(
        content: Text(
          'Erro ao alterar o cartao',
        ),
      ));
      Navigator.of(context).pop(false);
    });
  }
}
