import 'package:expense_tracker/components/cartao_item.dart';
import 'package:expense_tracker/models/cartao.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../repository/cartao_repository.dart';

class CartoesPage extends StatefulWidget {
  const CartoesPage({super.key});

  @override
  State<CartoesPage> createState() => _CartoesPageState();
}

class _CartoesPageState extends State<CartoesPage> {
  final cartoesRepo = CartaoRepository();
  late Future<List<Cartao>> cartoesFuture;
  User? user;

  @override
  void initState() {
    user = Supabase.instance.client.auth.currentUser;
    cartoesFuture = cartoesRepo.listarCartoes(cartaoId: user?.id ?? '');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cartões'),
      ),
      body: FutureBuilder<List<Cartao>>(
        future: cartoesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return const Center(
              child: Text("Erro ao carregar cartão"),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text("Nenhuma cartão encontrado"),
            );
          } else {
            final cartoes = snapshot.data!;
            return ListView.separated(
              itemCount: cartoes.length,
              itemBuilder: (context, index) {
                final cartao = cartoes[index];
                return CartaoItem(cartao: cartao);
              },
              separatorBuilder: (context, index) => const Divider(),
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        heroTag: "cartao-cadastro",
        onPressed: () {
          Navigator.pushNamed(context, '/cartao-cadastro');
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
